module Main where

import qualified MyLib (someFunc)
import qualified Simulate as S
import Types
import Kinematics
import Behaviors
import Simulate
import Data.List(cycle)
import Visualization(animateSimulation)
import Graphics.Gloss.Data.Color

-- | The main entry point.
initializeEntity :: Position -> Velocity -> Entity 
initializeEntity pos vel = Entity pos vel (Acceleration 0 0 0) red
-- initilize entity is a function that takes a position and velocity and returns an entity
-- an entity is 
dt :: Double
dt = 0.1
maxSimulationTime :: Float
maxSimulationTime = 10

someConstantVelocity :: Velocity
someConstantVelocity = Velocity 1 1 1

controlPoints :: [Position]
controlPoints = [Position 0 0 0, Position 10 10 10, Position 20 20 20, Position 30 30 30, Position 40 40 40]
-- | The main entry point.

targetpath :: [Position]
targetpath = cycle $ generateTargetPath controlPoints

updateTarget :: Position -> Entity -> Entity 
updateTarget newPosition target = target { entityPosition = newPosition}

runSimulate :: Entity -> [Position] ->Float -> IO()
runSimulate drone (newPosition:restOfPath) time = do 
    putStrLn $ "Simulation Time" ++ show time
    let updateDrone = hover $ updateEntity drone (realToFrac dt)
    let updatedTarget = updateTarget newPosition (initializeEntity newPosition S.someConstantVelocity)
      --moveLinearly someConstantVelocity (Entity targetPos (Velocity 0 0 0) (Acceleration 0 0 0) blue) 

    if time >= maxSimulationTime 
      then putStrLn "Simulation Complete"
      else runSimulate updateDrone restOfPath (time + realToFrac dt)

main :: IO ()
main = do 
  animateSimulation
  MyLib.someFunc

    -- Setting initial conditions for drone and target
  let drone = initializeEntity (Position 0 0 0) (Velocity 0 0 0)
  let controlPoints = [Position 0 0 0, Position 10 10 10, Position 20 20 20, Position 30 30 30, Position 40 40 40]
  let targetpath = S.generateTargetPath controlPoints
  let initalTarget = initializeEntity (head targetpath) S.someConstantVelocity

    -- Printing out the initial states
  putStrLn $ "Initial Drone State: " ++ show drone
  putStrLn $ "Initial Target State: " ++ show initalTarget
      -- Running the simulation
  runSimulate drone targetpath 0

  animateSimulation
