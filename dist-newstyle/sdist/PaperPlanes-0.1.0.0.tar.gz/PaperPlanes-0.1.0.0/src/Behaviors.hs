module Behaviors where 

import Types
import Kinematics
import Prelude hiding (cos, sin)
import qualified Prelude as P
import Graphics.Gloss.Data.Color

hover :: Entity -> Entity
hover (Entity pos _ _ color) = Entity pos (Velocity 0 0 0) (Acceleration 0 0 0) color

moveLinearly :: Velocity -> Entity -> Entity 
moveLinearly (Velocity vx vy vz) (Entity pos _ _ color) = Entity pos (Velocity vx vy vz) (Acceleration 0 0 0) color

accelerate :: Acceleration -> Entity -> Entity 
accelerate acc (Entity pos vel _ color) = Entity pos vel acc color

turn :: Float -> Entity -> Entity
turn angle (Entity pos (Velocity vx vy vz) acc color) = 
    Entity pos (Velocity (vx * P.cos (realToFrac angle) - vy * P.sin (realToFrac angle)) 
                         (vx * P.sin (realToFrac angle) + vy * P.cos (realToFrac angle)) vz) acc color

chase :: Entity -> Entity -> Entity 
chase (Entity (Position dx dy dz) _ _ droneColor) (Entity (Position tx ty tz) _ _ _) = 
    let
        directionX  = signum (tx - dx)
        directionY = signum (ty - dy)
        directionZ  = signum (tz -dz)
        chaseSpeed = 0.8
        newVel = Velocity (directionX *chaseSpeed) (directionY * chaseSpeed) (directionZ * chaseSpeed)
    in Entity (Position dx dy dz) newVel (Acceleration 0 0 0) droneColor

-- because position velocity and color are defined
initialPosition :: Position 
initialPosition = Position 0 0 0

initialVelocity :: Velocity
initialVelocity = Velocity 0 0 0

initialAcceleration :: Acceleration
initialAcceleration = Acceleration 0 0 0



initialErraticTarget :: Entity 
initialErraticTarget = Entity initialPosition initialVelocity initialAcceleration red
-- this 

erraticMove :: Float -> Entity -> Entity 
erraticMove time (Entity pos (Velocity vx vy vz) acc color) = 
    let 
        newVelX = vx + (P.sin (realToFrac time)) -- sinsoidal variation because our target is lazy
        newVelY = vy + (P.cos (realToFrac time))
        newVelZ  = vz
    in Entity pos (Velocity newVelX newVelY newVelZ) acc color


